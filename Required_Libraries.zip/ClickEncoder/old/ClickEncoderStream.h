//
//  ClickEncoderStream.h
//  
//
//  Created by Christophe Persoz on 17/07/2016.
//  Copyright © 2016 Christophe Persoz. All rights reserved.
//

#ifndef ClickEncoderStream_h
#define ClickEncoderStream_h

#include <stdint.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/pgmspace.h>
#include "Arduino.h"
#include "ClickEncoder.h"

/*  emulate a stream based on clickEncoder movement returning +/- for every 'sensivity' steps
 buffer not needer because we have an accumulator
 */
class ClickEncoderStream:public Stream {
public:
    ClickEncoder &enc; //associated hardware clickEncoder
    int8_t sensivity;
    int oldPos;
    int pos;
    
    ClickEncoderStream(ClickEncoder &enc,int sensivity):enc(enc), sensivity(sensivity) {}
    
    inline void setSensivity(int s) {
        sensivity = s;
    }
    
    int available(void) {
        return (abs(enc.encValue - oldPos) / sensivity);
    }
    
    int peek(void) {
        int d = enc.encValue - oldPos;
        if (d <= -sensivity)
            return '-';
        if (d >= sensivity)
            return '+';
        return -1;
    }
    
    int read()
    {
        int d = enc.encValue - oldPos;
        if (d <= -sensivity) {
            oldPos -= sensivity;
            return '-';
        }
        if (d >= sensivity) {
            oldPos += sensivity;
            return '+';
        }
        return -1;
    }
    
    void flush() {
        oldPos = enc.encValue;
    }
    size_t write(uint8_t v)
    {
        oldPos = v;
        return 1;
    }
};


#endif /* ClickEncoderStream_h */
